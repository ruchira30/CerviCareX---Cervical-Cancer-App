package com.example.cervicalcancer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
